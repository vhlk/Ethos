from django.contrib import admin

#colocar aqui o metodo admin referenciando o 'rede'